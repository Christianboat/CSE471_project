$(document).ready(function() {
    // Code for dynamic behavior (if needed)
});
